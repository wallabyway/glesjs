
var gl = (typeof _gl === "undefined") ? twgl.getWebGLContext(document.getElementById("c")):_gl;

WebGLBuffer = function() {};

gl.getActiveUniform = function (program, ii) {
    //var a = gl.getActiveUniform(program, ii); console.log("!!!"+a.size+a.name+a.type);return a;
    if (ii == 0) 
        return {name:"u_worldViewProjection",size:1,type:35676}
    else if (ii == 1) 
        return {name:"u_texture",size:1,type:35678}
    return undefined;
}

gl.getActiveAttrib = function (program, ii) {
    //var a = gl.getActiveAttrib(program, ii); console.log(a.name);
    if (ii == 0) 
        return {name:"a_texcoord"};
    else if (ii == 1) 
        return {name:"a_position"};
}

gl.getProgramParameterx = function (program, id) {
    if (id == gl.ACTIVE_ATTRIBUTES) return 1;
    return gl.getProgramParameter(program, gl.ACTIVE_ATTRIBUTES);
}


    twgl.setAttributePrefix("a_");
    var m4 = twgl.m4;
    var programInfo = twgl.createProgramInfo(gl, ["vs", "fs"]);
    var bufferInfo = twgl.primitives.createCubeBufferInfo(gl, 2);

    console.log('reading texture')
/*    
    var tex = twgl.createTexture(gl, {
            mag: gl.NEAREST,
            min: gl.LINEAR,
            src: [
              255,255,255,255,
              192,192,192,255,
              192,192,192,255,
              255,255,255,255,
            ],
    });
*/

// returns texture id
function initTexture(gl,imageurl,smooth,wrap) {
    var texture = gl.createTexture();
    var image = new Image();
    image.onload = function() {
        gl.bindTexture(gl.TEXTURE_2D, texture);
        // XXX image.src -> image
        gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA, gl.UNSIGNED_BYTE, image);
        if (smooth) {
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        } else {
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
            gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
        }
        if (wrap) {
            gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S, gl.REPEAT);
            gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T, gl.REPEAT);
        } else {
            gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
            gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        }
        gl.bindTexture(gl.TEXTURE_2D, null);
    };
    image.src = imageurl;
    return texture;
}


    var tex = initTexture(gl,"images/goldengate.jpg",false,false);
    var uniforms = {
      u_texture: tex,
    };

    var time = 0;
    function render() {
      requestAnimationFrame(render);
      time += 0.01;
      //twgl.resizeCanvasToDisplaySize(gl.canvas,1);
      gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);

      gl.enable(gl.DEPTH_TEST);
      //gl.enable(gl.CULL_FACE);

      gl.clearColor(0.4,0.4,0.5,1);
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

      var projection = m4.perspective(30 * Math.PI / 180, gl.canvas.width / gl.canvas.height, 0.5, 10);
      var eye = [1, 4, -6];
      var target = [0, 0, 0];
      var up = [0, 1, 0];

      var camera = m4.lookAt(eye, target, up);
      var view = m4.inverse(camera);
      var viewProjection = m4.multiply(view, projection);
      var world = m4.rotationY(time);

      uniforms.u_viewInverse = camera;
      uniforms.u_world = world;
      uniforms.u_worldInverseTranspose = m4.transpose(m4.inverse(world));
      uniforms.u_worldViewProjection = m4.multiply(world, viewProjection);

      gl.useProgram(programInfo.program);
      twgl.setBuffersAndAttributes(gl, programInfo, bufferInfo);
      twgl.setUniforms(programInfo, uniforms);
      gl.drawElements(gl.TRIANGLES, bufferInfo.numElements, gl.UNSIGNED_SHORT, 0);
    }
    render();

